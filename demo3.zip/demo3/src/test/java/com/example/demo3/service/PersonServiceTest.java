package com.example.demo3.service;

import com.example.demo3.entity.PersonEntity;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class PersonServiceTest {

    @Autowired
    private PersonService personService;

    @Test
    void crudFlowWorksAgainstEmbeddedDb() {
        // Create
        PersonEntity created = personService.create(new PersonEntity("Alice", 20));
        assertThat(created.getId()).isNotNull();

        // Read
        PersonEntity fetched = personService.get(created.getId());
        assertThat(fetched.getName()).isEqualTo("Alice");

        // Update
        PersonEntity input = new PersonEntity("Alice Updated", 21);
        PersonEntity updated = personService.update(created.getId(), input);
        assertThat(updated.getName()).isEqualTo("Alice Updated");
        assertThat(updated.getAge()).isEqualTo(21);

        // List
        List<PersonEntity> all = personService.list();
        assertThat(all).hasSize(1);

        // Delete
        personService.delete(created.getId());
        assertThat(personService.list()).isEmpty();
    }
}

