package com.example.demo3.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * 简单的代理 Controller，将前端请求转发到网易云音乐，避免直接跨域。
 */
@RestController
@RequestMapping("/api/music")
public class MusicController {

    private static final String SONG_URL_TEMPLATE = "http://music.163.com/song/media/outer/url?id=%s.mp3";
    private static final Logger log = LoggerFactory.getLogger(MusicController.class);

    private static final String NETEASE_COOKIE =
            "_iuqxldmzr_=32; "
                    + "_ntes_nnid=04fe80977a0fa825d6cd497a78b31086,1764166461667; "
                    + "_ntes_nuid=04fe80977a0fa825d6cd497a78b31086; "
                    + "NMTID=00OdVXfbQxNE1LI-EHxtjlnEKacrIIAAAGawIPqGg; "
                    + "WEVNSM=1.0.0; "
                    + "WNMCID=zrbzzm.1764166463714.01.0; "
                    + "ntes_utid=tid._.v3AY9BzRrwNER0AFRAOCzKAFgA6uOQOh._.0; "
                    + "sDeviceId=YD-Z4M5ROjQsU1EFlAEUEPWzeAVhQ%2F%2FOAf1; "
                    + "WM_TID=bCmOgf5bjFRBBFFFAEPC2PRA1FquX%2FMf; "
                    + "__snaker__id=ssw51lw2aLDVu1kL; "
                    + "__csrf=0ed583c51d87d494d037bbc731d27ed8; "
                    + "MUSIC_U=008904DBF5712A25CA5033F286884C4A02C8B314EA000248D3170DC483B62F16F57B3E542C8EA708FEB5D7E01E011ADEBB4BCFE546095DBAE7459EB14B439AA0241972D6E5A2D60984E6C52B59063FBB536343BBC736E0514A4CE3E3268144D13A7F970A46F77743264EFE3E102D40925EBB0436D3D180BAD9904730F8852F7B4A4F39EA678CE373E8A16944F8644C005BDC30D96AF8218A976A97A7607D403C6D6CE325982D4B41B7C7AD9AD3D471A2D6622A0A21054B58725410B51409D4877EB27B260954439750709794039D7F775552B8EDF0DE94533A86678E63D36C837436630275958FC9C600C739CFB4CB6089A4B91FFCF4E5D86D207B8499881328B2174C4F2A45135C26F18C4EDD4AB967FB2910F7193F0CEA9088FA0B4A3CD4B6C2F7FD70C8A107AAA5DF8A4E9E0A8421CE8CCD94A8087899D3C366740F9BB1952C0615BF8682075B288AD30753E475F3EC5C8E359BB84AEF8DA57D990DBDAD486D6A15CE674F0ACDE96481449FFF3AEAC464B154280CBA53506909223FBD666A7B7F39671232C9AFAC35C540E90A5944DEA64D9DA001714FB2325B1933F017FBAEDB42CBBFFB948D4DD09F83AF25557C717843AD972437FA2991B4445D79DA838C; "
                    + "ntes_kaola_ad=1; "
                    + "playerid=15241368; "
                    + "WM_NI=93fD7Aajl8USHFnQaV8pytQD%2BsTTlwPj5PtsLimhckreZ97aoRKF4%2BOUh0GCIdjn%2BxdIMnYzoLqnCgByqBSBnyTLhvckH54MZ2VWUMljND1TyZzFG16aWN48rT2VPEDNVkc%3D; "
                    + "WM_NIKE=9ca17ae2e6ffcda170e2e6eed0eb7297ebbab6d03494968ba7d84f929b9fb0d63aa78fa9d5ce5eb2bfa7b5ed2af0fea7c3b92afbedaaa5b64ba3b6a4d9d8598c9aa2b2e45efcb0b795d450e9ad9cb5ef7d94b6fbb1f77990b7a389e261b2bb96dab66bad8e85a7b7218d8ba8d1c6498bbca68faa74a897838fdc72ad94bf8fc26d82a7bfa3d24aaea79cadeb7ea1b588d6b7479aee9ab8d847b0b682a5b460bb86b6a7c63bf6bf99afb734b28cfeb7d34f88929a8ce237e2a3; "
                    + "gdxidpyhxdE=ulTe5ayCOO2Jzurh34OW7RnS091NnKfnD%5C%2B2zQZ%5CwnOkvGCLx%2FcdRq19twnW90fnp7%5Cb%5CeN2cub0QymiSpw6%2BO%2B%5C9XJ%2F7x8m3KWHhgPqImD2NJAlVqGgGpi0CBNJSXtn5owOTr2V%5CHv46vbXcfdCY8aRz3JPA%2F6SCn3Gh%2F2AbrZ1OAUI%3A1764239725344; "
                    + "JSESSIONID-WYYY=AJqxvlRM7QpGND9fEeGwz%5C%2FNuV%2FEG7m3XG8hs%2FG2qx%2FoDEbG%2Fo8y%2BqB4djsHY%2ByDKp5hOaxMPhCDIUeRYN%2BZaX5MEeO5hqrCceXkWkr4WlmPcRFcXBmnIBJ%5CFXRV5ZY%2FdqVFootENyHoFO6cJXY242stzdDirCU9lEuuDycYbM%2FETNvV%3A1764240679402";

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @GetMapping("/search")
    public ResponseEntity<String> search(@RequestParam String key) {
        try {
            log.info("开始搜索关键词: {}", key);
            JsonNode searchResult = querySearchApi(key);
            JsonNode songs = searchResult.path("result").path("songs");
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("keyword", key);
            payload.set("songs", buildSongsWithUrl(songs));
            payload.set("raw", searchResult);

            log.info("搜索完成，命中 {} 条歌曲", payload.path("songs").size());
            return ResponseEntity.ok(payload.toString());
        } catch (Exception e) {
            log.error("搜索关键词 {} 失败: {}", key, e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body("{\"error\":\"服务开小差，请稍后重试\"}");
        }
    }

    private JsonNode querySearchApi(String keyword) throws Exception {
        String encodedKey = URLEncoder.encode(keyword, StandardCharsets.UTF_8);
        String url = "http://music.163.com/api/search/get/web"
                + "?csrf_token="
                + "&hlpretag="
                + "&hlposttag="
                + "&s=" + encodedKey
                + "&type=1&offset=0&total=true&limit=5";

        HttpHeaders headers = defaultHeaders();
        ResponseEntity<String> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                String.class
        );
        return objectMapper.readTree(response.getBody());
    }

    private JsonNode buildSongsWithUrl(JsonNode songsNode) {
        ArrayNode songsWithUrl = objectMapper.createArrayNode();
        if (songsNode.isArray()) {
            for (JsonNode songNode : songsNode) {
                long id = songNode.path("id").asLong();
                String mediaUrl = String.format(SONG_URL_TEMPLATE, id);
                int mediaStatus = probeMediaUrl(mediaUrl);

                ObjectNode node = objectMapper.createObjectNode();
                node.put("id", id);
                node.put("name", songNode.path("name").asText(""));
                node.set("artists", songNode.path("artists"));
                node.put("mediaUrl", mediaUrl);
                node.put("mediaStatus", mediaStatus);
                songsWithUrl.add(node);
            }
        }
        return songsWithUrl;
    }

    private int probeMediaUrl(String mediaUrl) {
        HttpHeaders headers = defaultHeaders();
        try {
            ResponseEntity<Void> response = restTemplate.exchange(
                    mediaUrl,
                    HttpMethod.HEAD,
                    new HttpEntity<>(headers),
                    Void.class
            );
            return response.getStatusCodeValue();
        } catch (Exception e) {
            log.warn("探测音频地址失败: {} - {}", mediaUrl, e.getMessage());
            return 0;
        }
    }

    private HttpHeaders defaultHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Host", "music.163.com");
        headers.set("Connection", "keep-alive");
        headers.set("Accept", "application/json, text/plain, */*");
        headers.set("Accept-Language", "zh-CN,zh;q=0.9");
        headers.set("X-Real-IP", "211.161.244.70");
        headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36");
        headers.set("Referer", "http://music.163.com/");
        headers.set("Content-Type", "application/x-www-form-urlencoded");
        headers.set("Cookie", NETEASE_COOKIE);
        return headers;
    }
}

