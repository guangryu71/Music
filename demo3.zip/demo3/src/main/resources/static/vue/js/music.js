
var app = new Vue({
    el: "#box",
    data: {
        musicName: "",
        loading: false,
        result: null
    },
    methods: {
        getMusic: function () {
            if (!this.musicName.trim()) {
                alert("请输入歌曲名称");
                return;
            }
            this.loading = true;
            this.result = null;
            var that = this;
            axios.get("/api/music/search", {
                params: { key: that.musicName }
            }).then(function (response) {
                that.result = response.data;
                console.log("音乐搜索结果：", that.result);
            }).catch(function (err) {
                console.log("出错了：" + err);
                alert("请求失败：" + err);
            }).finally(function () {
                that.loading = false;
            });
        }
    }
});